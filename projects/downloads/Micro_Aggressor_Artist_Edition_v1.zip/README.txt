========================================================================
MICRO AGGRESSOR - Artist Edition VST3
Developed by Blacklist Technologies New York City
========================================================================

Thank you for choosing the Micro Aggressor. This boutique plugin is 
designed for aggressive transient shaping, parallel compression, and 
analog-style saturation.

INSTALLATION INSTRUCTIONS (WINDOWS)
-----------------------------------
1. Copy the "Micro Aggressor.vst3" folder to your system VST3 directory:
   C:\Program Files\Common Files\VST3\

2. Open your DAW (Ableton Live, FL Studio, Cubase, etc.).

3. Rescan your plugins. The plugin will appear under:
   Manufacturer: Blacklist Technology
   Category: Dynamics / Distortion

INSTALLATION INSTRUCTIONS (macOS)
---------------------------------
1. Copy the "Micro Aggressor.vst3" bundle to your system VST3 directory:
   /Library/Audio/Plug-Ins/Components/

2. Open your DAW.

3. Rescan your plugins.

FEATURES
--------
- SMACK: Secondary aggressive parallel path gain.
- CLARITY: 1kHz Pivot Tilt EQ (-12dB to +12dB).
- LEVEL: Master output gain.
- BLOOM: Primary compression sustain/intensity.
- MIX: Master Dry/Wet parallel blend.
- LUMINA TOGGLE: Switch between SLATE (Dark) and GHOST (Light) modes.

SUPPORT
-------
For technical support or feature requests, visit:
https://blacklist.tech
Email: jahn@blacklist.tech

(c) 2026 Blacklist Technology. Built for Artists, by Artists.
========================================================================
